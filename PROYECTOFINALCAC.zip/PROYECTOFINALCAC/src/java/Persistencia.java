
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
//se importaron las librerias


public class Persistencia {
    //armo conexion con la base de datos
    //creo variables de tipo privadas
    
    private Connection cn;
    private ResultSet rs;
    private PreparedStatement ps;
    private ResultSetMetaData rsm;
    
    //ahora defino las variables publicas
    
    public String servidor , basededatos , usuario , clave , ejecutar;
            
            //defino un metodo para hacer la conexion
    public Connection conectarse(){
        
        //try and catch sirve para ver las excepciones que puede haber en la conexion
        try {
            Class.forName("com.mysql.jdbc.Driver");

        
        //paso las variables que uso para establecer la conexion
        
        servidor = "localhost:3306/"; //remotemysql.com  sino es 127.0.01 es localhost
        
        basededatos = "cacproyecto1110";
        
        usuario = "root";
        
        clave = "";
        
        
        cn=DriverManager.getConnection("jdbc:mysql://" + servidor + basededatos+"?autoReconnect=true&userSSL=false" , usuario , clave);
        
          } catch (ClassNotFoundException ex) {
            Logger.getLogger(Persistencia.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Persistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cn; //retorno lo que es la conexion
    }
            
  //****************************************************
    
    public ResultSet  consultaSQL( String busqueda){
        
        try {
            //me devuelve el resultado de la consulta

            ps = conectarse().prepareStatement(busqueda);
        
        
        //prepare llama al objeto para obtener la conexion con el metodo conectarse
        
        rs = ps.executeQuery();
        
        rsm=rs.getMetaData();
        
        } catch (SQLException ex) {
            Logger.getLogger(Persistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
    }
}
